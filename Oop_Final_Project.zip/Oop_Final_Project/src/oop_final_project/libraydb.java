/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package oop_final_project;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement; // Import PreparedStatement
import java.sql.ResultSet; // Import ResultSet
import java.sql.SQLException;
import java.util.Scanner;

/**
 *
 * @author crist
 */

public class libraydb {
    private static final String URL = "jdbc:mysql://localhost:3306/librarydb";
    private static final String USER = "root";
    private static final String PASSWORD = "cjcutie";
    
     public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
     
     public static boolean validateAdmin(String username, String password) throws SQLException {
        String query = "SELECT * FROM admin WHERE usernameAdmin = ? AND passwordAdmin = ?";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, username);
            stmt.setString(2, password);
            ResultSet rs = stmt.executeQuery();
            return rs.next();
        }
    }

    // Method to check if user credentials are valid
    public static boolean validateUser(String username, String password) throws SQLException {
        String query = "SELECT * FROM user WHERE usernameUser = ? AND passwordUser = ?";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, username);
            stmt.setString(2, password);
            ResultSet rs = stmt.executeQuery();
            return rs.next();
        }
    
    }
    public static boolean signUpAdmin(String username, String password) throws SQLException {
        String query = "INSERT INTO admin (usernameAdmin, passwordAdmin) VALUES (?, ?)";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, username);
            stmt.setString(2, password);
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        }
    }

    // Method to create a new user
    public static boolean signUpUser(String username, String firstname, String lastname, String birthday, String password) throws SQLException {
        String query = "INSERT INTO user (usernameUser, firstnameUser, lastnameUser, birthday, passwordUser) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, username);
            stmt.setString(2, firstname);
            stmt.setString(3, lastname);
            stmt.setString(4, birthday);
            stmt.setString(5, password);
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        }
    }
}


