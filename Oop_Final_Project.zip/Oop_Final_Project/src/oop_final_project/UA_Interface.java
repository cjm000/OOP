package oop_final_project;

public interface UA_Interface {
    boolean login(String username, String password); 
    boolean signUp(String username, String firstName, String lastName, String birthday, String password);
    void viewBorrowedBooks(); // View borrowed books method
}
