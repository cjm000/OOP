package oop_final_project;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java. util.*;

public class user_Class extends UA_Abstract {
 private static final String URL = "jdbc:mysql://localhost:3306/librarydb";
    private static final String USER = "root";
    private static final String PASSWORD = "cjcutie";
    // Constructor for the user_Class
    public user_Class(int id, String username, String password, String firstName, String lastName, String birthday) {
        super(id, username, password, firstName, lastName, birthday);
    }

    @Override
    public boolean login(String username, String password) {
        // User-specific login logic
        try {
            if (LibDB.validateUser(username, password)) {               
                return true;
            } else {
                System.out.println("Invalid User credentials.");
                return false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean signUp(String username, String firstName, String lastName, String birthday, String password) {
        // User-specific sign up logic
         if (isUsernameTaken(username)) {
                System.out.println("Username is already taken. Please choose another.");
                return false;
            }
        try {
            if (LibDB.signUpUser(username, firstName, lastName, birthday, password)) {              
                return true;
            } else {               
                return false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
     public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
    private boolean isUsernameTaken(String username) {
        String query = "SELECT COUNT(*) FROM user WHERE usernameUser = ?";
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement stmt = connection.prepareStatement(query)) {

            stmt.setString(1, username);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return rs.getInt(1) > 0;  // If count > 0, username exists
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;  // Username doesn't exist
    }
    
    public void tryUser(){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter username:");
                    String userUsername = sc.nextLine();
                    System.out.println("Enter password:");
                    String userPassword = sc.nextLine();
                    user_Class user = new user_Class(0, userUsername, userPassword, null, null, null);
                    if (user.login(userUsername, userPassword)) {
                    System.out.print("\n--------------------------------------------------\n");
                        System.out.println("Welcome, " + userUsername);
                        correctUser();
                       
                    } else {
                        System.out.println("Invalid credentials. Try again.");
                    }
    }
    public void registerUser(){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter username:");
                    String newUserUsername = sc.nextLine();
                    System.out.println("Enter first name:");
                    String firstName = sc.nextLine();
                    System.out.println("Enter last name:");
                    String lastName = sc.nextLine();
                    System.out.println("Enter birthday (yyyy-MM-dd):");
                    String birthday = sc.nextLine();
                    System.out.println("Enter password:");
                    String newUserPassword = sc.nextLine();
                    user_Class newUser = new user_Class(0, newUserUsername, newUserPassword, firstName, lastName, birthday);
                    if (newUser.signUp(newUserUsername, firstName, lastName, birthday, newUserPassword)) {
                        System.out.println("User signed up successfully!");
                    } else {
                        System.out.println("Sign-up failed. Try again.");
                    }
    }
    
    public void correctUser(){
         Scanner sc = new Scanner(System.in);
        System.out.print("-------------------------------------------------");               
                        int userChoice;
                        while(true){
                            System.out.println("\nUser Menu");
                            System.out.println("[1] View Books");
                            System.out.println("[2] Search Books");
                            System.out.println("[3] Borrowed Books");
                            System.out.println("[4] Exit");                           
                            System.out.print("Enter your choice: ");
                            userChoice = sc.nextInt();
                            sc.nextLine();
                            book_methods bookobj = new book_methods();
                           switch (userChoice) {
                                
                                case 1:
                                   bookobj.showBooks();
                                    break;
                                case 2:
                                    bookobj.searchEngine();
                                    break;
                                case 3:
                                    viewBorrowingHistory(username);
                                    break;
                                case 4:
                                    System.out.println("Logging out...");
                                    return;                                                                                            
                                default:
                                    System.out.println("Invalid choice. Try again.");
                            }
                        }                     
    }

    @Override
    public void viewBorrowedBooks() {
        // Placeholder for viewing borrowed books
        System.out.println("Viewing borrowed books...");
        // You would implement logic to fetch and display borrowed books here.
    }

    @Override
    public boolean signUpAdmin(String username, String password) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    public void viewBorrowingHistory(String username) {
    // SQL query to fetch the borrowing history
    String historyQuery = "SELECT b.idBook, b.title, b.author, b.stock, b.year, b.genre, " +
                          "br.borrow_date, br.return_date " +
                          "FROM borrowed br " +
                          "JOIN book b ON br.book_id = b.idBook " +
                          "WHERE br.borrower_username = ? " +
                          "ORDER BY br.borrow_date DESC";

    try (Connection conn = getConnection(); // Assuming you have a method for DB connection
         PreparedStatement stmt = conn.prepareStatement(historyQuery)) {

        // Set the username parameter in the query
        stmt.setString(1, username);

        ResultSet rs = stmt.executeQuery();

        boolean found = false;
        // Display the borrowing history
        while (rs.next()) {
            int bookId = rs.getInt("idBook");
            String title = rs.getString("title");
            String author = rs.getString("author");
            int stock = rs.getInt("stock");
            int year = rs.getInt("year");
            String genre = rs.getString("genre");
            Date borrowDate = rs.getDate("borrow_date");
            Date returnDate = rs.getDate("return_date");

            // Display the borrowing details
            System.out.println("\nBook ID: " + bookId);
            System.out.println("Title: " + title);
            System.out.println("Author: " + author);
            System.out.println("Stock: " + stock);
            System.out.println("Year: " + year);
            System.out.println("Genre: " + genre);
            System.out.println("Borrow Date: " + borrowDate);
            System.out.println("Return Date: " + (returnDate != null ? returnDate : "Not returned yet"));
            System.out.println("------------------------------------------");
            found = true;
        }

        // If no borrowing history is found
        if (!found) {
            System.out.println("No borrowing history found for the username: " + username);
        }

    } catch (SQLException e) {
        e.printStackTrace();
    }
}


    
}
