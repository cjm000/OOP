/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package oop_final_project;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;
import static oop_final_project.book_Class.getConnection;

/**
 *
 * @author crist
 */
public class book_methods {
    Scanner sc = new Scanner(System.in);
    
    public void addBook(){
    System.out.println("Enter book title: ");
    String title = sc.nextLine();
    System.out.println("Enter book author: ");
    String author = sc.nextLine();
    System.out.println("Enter stock: ");
    int stock = sc.nextInt();
    System.out.println("Enter publication year: ");
    int year = sc.nextInt();
    sc.nextLine(); // Consume newline
    System.out.println("Enter genre: ");
    String genre = sc.nextLine();

    book_Class book = new book_Class(0, title, author, stock, year, genre,"","");
    if (book.addBook()) {
        System.out.println("Book added successfully!");
    } else {
        System.out.println("Failed to add book.");
    }
    }
    public void deleteBook(){
    
    System.out.print("Enter book title: ");
    String title = sc.nextLine();
    System.out.print("Enter book id: ");
    int id = sc.nextInt();
    book_Class book = new book_Class(id, title, "",0,0, "","","");
    if (book.deleteBook()) {
        System.out.println("Book deleted successfully.");
    } else {
        System.out.println("Failed to delete book.");
    }
   }
    public void showBooks() {
    // Adjusted query if the correct table name is 'books' (or 'book' if that's correct)
    String SHOW_BOOKS = "SELECT * FROM book";  // Make sure 'books' matches your actual table name
    
    try (Connection conn = getConnection();  // Make sure getConnection() is working properly
         PreparedStatement stmt = conn.prepareStatement(SHOW_BOOKS);
         ResultSet rs = stmt.executeQuery()) {

        // Iterate over each row in the result set
        while (rs.next()) {
            int id = rs.getInt("idBook");  // Assuming 'id' is the column name, change if needed
            String title = rs.getString("title");
            String author = rs.getString("author");
            int stock = rs.getInt("stock");
            int year = rs.getInt("year");
            String genre = rs.getString("genre");

            // Display the book details
            System.out.println("ID: " + id);
            System.out.println("Title: " + title);
            System.out.println("Author: " + author);
            System.out.println("Stock: " + stock);
            System.out.println("Year: " + year);
            System.out.println("Genre: " + genre);
            System.out.println("----------------------------------------");
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
}
    
     public void searchEngine() {
    Scanner sc = new Scanner(System.in);
    System.out.println("\nSearch Menu:");
    System.out.println("[1] Genre");
    System.out.println("[2] Title");
    System.out.println("[3] Author");
    System.out.println("[4] Year");
    System.out.println("[5] Exit");                           
    System.out.print("Enter your choice: ");
    int userChoice = sc.nextInt();
    sc.nextLine();  // Consume the newline character

    String query = "";
    String searchValue = "";
    
    // Based on the user's choice, set up the query and get input
    switch (userChoice) {
        case 1: // Search by Genre
            System.out.print("Enter genre to search: ");
            searchValue = sc.nextLine();
            query = "SELECT * FROM book WHERE genre LIKE ?";
            break;
        case 2: // Search by Title
            System.out.print("Enter title to search: ");
            searchValue = sc.nextLine();
            query = "SELECT * FROM book WHERE title LIKE ?";
            break;
        case 3: // Search by Author
            System.out.print("Enter author to search: ");
            searchValue = sc.nextLine();
            query = "SELECT * FROM book WHERE author LIKE ?";
            break;
        case 4: // Search by Year
            System.out.print("Enter year to search: ");
            searchValue = sc.nextLine();
            query = "SELECT * FROM book WHERE year = ?";
            break;
        case 5: // Exit
            System.out.println("Exiting search menu.");
            return;
        default:
            System.out.println("Invalid choice, please try again.");
            return;
    }

    // Execute the query and display results
    try (Connection conn = getConnection(); 
         PreparedStatement stmt = conn.prepareStatement(query)) {
        
        if (userChoice == 4) {
            // For year, we use an integer parameter
            stmt.setInt(1, Integer.parseInt(searchValue));
        } else {
            // For other fields, we use string parameters with a wildcard (for partial matching)
            stmt.setString(1, "%" + searchValue + "%");
        }
        
        ResultSet rs = stmt.executeQuery();
        
        // Display results
        boolean found = false;
        while (rs.next()) {
            int id = rs.getInt("idBook");
            String title = rs.getString("title");
            String author = rs.getString("author");
            int stock = rs.getInt("stock");
            int year = rs.getInt("year");
            String genre = rs.getString("genre");

            // Print book details
            System.out.println("\nID: " + id);
            System.out.println("Title: " + title);
            System.out.println("Author: " + author);
            System.out.println("Stock: " + stock);
            System.out.println("Year: " + year);
            System.out.println("Genre: " + genre);
            System.out.println("------------------------------------------");
            found = true;
        }
        
        if (!found) {
            System.out.println("No books found for your search.");
        }
        
    } catch (SQLException e) {
        e.printStackTrace();
    }
}
}
