package oop_final_project;

public abstract class UA_Abstract implements UA_Interface {
    protected int id;
    protected String username;
    protected String password;
    protected String firstName;
    protected String lastName;
    protected String birthday;
    
    // Constructor to initialize common properties
    public UA_Abstract(int id, String username, String password, String firstName, String lastName, String birthday) {
        this.id = id;
        this.username = username;
        this.password = password;
        this.firstName = firstName;
        this.lastName = lastName;
        this.birthday = birthday;
    }

    // Default behavior for login (can be overridden)
    @Override
    public boolean login(String username, String password) {
        System.out.println("Logging in with default behavior.");
        return false; // Default implementation, could be overridden
    }

    // Default behavior for sign up (can be overridden)
    @Override
    public boolean signUp(String username, String firstName, String lastName, String birthday, String password) {
        System.out.println("Signing up with default behavior.");
        return false; // Default implementation, could be overridden
    }

    // Abstract method for specific login logic (for each subclass)
    public abstract boolean signUpAdmin(String username, String password);
}
