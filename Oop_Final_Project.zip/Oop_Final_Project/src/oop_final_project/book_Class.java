/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package oop_final_project;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import static oop_final_project.LibDB.getConnection;
import java.util.*;
import static oop_final_project.user_Class.getConnection;
/**
 *
 * @author crist
 */
public class book_Class extends books_Abstract{
    private static final String URL = "jdbc:mysql://localhost:3306/librarydb";
    private static final String USER = "root";
    private static final String PASSWORD = "cjcutie";
    public book_Class(int id, String title, String author, int stock, int year, String genre,String borrower_username,String borrow_date) {
        super(id, title, author, stock, year, genre,borrower_username, borrow_date);
    }
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
    
 


    
    

 
    public boolean addBook() {
        String INSERT_BOOK = "INSERT INTO book (title, author, stock, year, genre) VALUES (?, ?, ?, ?, ?)";
       try (Connection conn = getConnection();
            PreparedStatement stmt = conn.prepareStatement(INSERT_BOOK)) {
            stmt.setString(1, this.title);
            stmt.setString(2, this.author);
            stmt.setInt(3, this.stock);
            stmt.setInt(4, this.year);
            stmt.setString(5, this.genre);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public boolean deleteBook(){
        String DELETE_BOOK = "DELETE FROM book WHERE title = ? AND author = ? OR idBook=?";
         try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(DELETE_BOOK)) {
            stmt.setString(1, this.title);
            stmt.setString(2,this.author);
            stmt.setInt(3, this.id);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
        
    }
    
    

    private boolean doesUserExist(String username) {
        String query = "SELECT COUNT(*) FROM user WHERE usernameUser = ?";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, username);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return rs.getInt(1) > 0;  // If count > 0, username exists
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;  // If username doesn't exist
    }
    private java.sql.Date getBorrowDateFromUser() {
        // Code to handle getting the borrow date from the user
        return java.sql.Date.valueOf("2024-12-07");  // Placeholder
    }
    
    
}
