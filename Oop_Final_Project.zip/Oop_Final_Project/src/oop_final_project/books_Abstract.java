/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package oop_final_project;

/**
 *
 * @author crist
 */
public abstract class books_Abstract {
    protected int id;
    protected String title;
    protected String author;
    protected int stock;
    protected int year;
    protected String genre;
    protected String borrower_username;
    protected String borrow_date;
    // Constructor for common properties
    public books_Abstract(int id, String title, String author, int stock, int year, String genre,String borrower_username,String borrow_date ) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.stock = stock;
        this.year = year;
        this.genre = genre;
        this.borrower_username = borrower_username;
        this.borrow_date=borrow_date;
    }
    public String getborrower_username() {
        return borrower_username;
    }

    public void setborrower_username(String borrower_username) {
       this.borrower_username = borrower_username;
    }
    
    public String getborrow_date() {
        return borrow_date;
    }

    public void setborrow_date(String borrow_date) {
       this.borrow_date=borrow_date;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }
   
    

}
