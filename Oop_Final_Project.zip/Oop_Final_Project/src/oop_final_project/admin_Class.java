package oop_final_project;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;
public class admin_Class extends UA_Abstract {
    private static final String URL = "jdbc:mysql://localhost:3306/librarydb";
    private static final String USER = "root";
    private static final String PASSWORD = "cjcutie";
    private static final String BORROW_BOOK = "INSERT INTO borrowed (borrower_username, book_id, borrow_date) VALUES (?, ?, ?)";
    private static final String CHECK_BOOK_EXISTS = "SELECT COUNT(*) FROM book WHERE idBook = ?";
    private static final String CHECK_USER_EXISTS = "SELECT COUNT(*) FROM user WHERE usernameUser = ?";
     
    // Constructor for Admin class
    public admin_Class(String username, String password) {
        super(0, username, password, null, null, null);
        // Admin does not need firstName, lastName, or birthday
    }
     public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    @Override
    public boolean login(String username, String password) {
        // Admin-specific login logic
        try {
            if (LibDB.validateAdmin(username, password)) {
                
                return true;
            } else {
               
                return false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
public boolean signUpAdmin(String username, String password) {
    try {
        // Step 1: Check if the username is already taken
        if (isUsernameTaken(username)) {
            System.out.println("Username is already taken. Please choose another.");
            return false;
        }

        // Step 2: If username is available, proceed with registration
        if (LibDB.signUpAdmin(username, password)) {           
            return true;
        } else {            
            return false;
        }
    } catch (SQLException e) {
        e.printStackTrace();
        return false;
    }
}


    @Override
    public void viewBorrowedBooks() {
        // This method can be left empty or can be implemented for admin's view of borrowed books
        System.out.println("Admins cannot borrow books, so this functionality is not available.");
    }

    public boolean signUp(String username, String password) {
        // Admin doesn't sign up as users do, so this method can throw an exception if called
        throw new UnsupportedOperationException("Admins cannot sign up like users.");
    }
    
    public void tryAdmin(){
         Scanner sc = new Scanner(System.in);
         System.out.print("Enter admin username:");
                    String adminUsername = sc.nextLine();
                    System.out.print("Enter admin password:");
                    String adminPassword = sc.nextLine();
                    admin_Class admin = new admin_Class(adminUsername, adminPassword);
                    if (admin.login(adminUsername, adminPassword)) {
                        admin.correctAdmin(); // Calls method to handle admin operations
                    } else {
                        System.out.println("Invalid admin credentials. Try again.");
                    }
    }
    
   
    public void correctAdmin(){
         Scanner sc = new Scanner(System.in);
        System.out.print("\n--------------------------------------------------\n"); 
        System.out.println("Welcome, Admin");
        System.out.print("--------------------------------------------------");
                        int adminChoice;
                        while(true){
                            System.out.println("\nAdmin Menu");
                            System.out.println("[1] Borrowing a Book");
                            System.out.println("[2] Returning a Book");
                            System.out.println("[3] Add Book");
                            System.out.println("[4] Remove a Book");
                            System.out.println("[5] Book Inventory");
                            System.out.println("[6] Book Search");
                            System.out.println("[7] Register New Admin");
                            System.out.println("[8] Log out");
                            System.out.print("Enter your choice: ");
                            adminChoice = sc.nextInt();
                            book_methods objbook = new book_methods();
                            sc.nextLine();
                           switch (adminChoice) {
                                
                                case 1:
                                    
                                    borrowBook();
                                    break;
                                case 2:
                                   
                                    returnBook();                                           
                                    break;
                                case 3:
                                  
                                    objbook.addBook();
                                    break;
                                case 4:
                                   
                                    objbook.deleteBook();
                                    break;
                                case 5:
                                    
                                    objbook.showBooks();
                                    break;
                                    case 6:                                  
                                    objbook.searchEngine();
                                    break;
                                case 7:                                
                                   registerNewAdmin();
                                    break;
                                case 8:
                                    // Admin log out
                                    System.out.println("Logging out...");
                                    return; // Exit the while loop and go back to the main menu
                                default:
                                    System.out.println("Invalid choice. Try again.");
                            }
                        }                     
    }
    
    
 public boolean returnBook() {
    Scanner scanner = new Scanner(System.in);
    System.out.print("Enter Borrower Username: ");
    String borrowerUsername = scanner.nextLine();
    System.out.print("Enter Book ID: ");
    int bookId = scanner.nextInt();
    System.out.print("Enter Return Date (YYYY-MM-DD): ");
    String returnDateInput = scanner.next();
    
    // The SQL queries
    String RETURN_BOOK = "UPDATE borrowed SET return_date = ? WHERE borrower_username = ? AND book_id = ?";
    String UPDATE_BOOK_STOCK = "UPDATE book SET stock = stock + 1 WHERE idBook = ?";

    try (Connection conn = getConnection();
         PreparedStatement returnStmt = conn.prepareStatement(RETURN_BOOK);
         PreparedStatement updateStmt = conn.prepareStatement(UPDATE_BOOK_STOCK)) {

        // Set the return date to the current date
        java.sql.Date returnDate = java.sql.Date.valueOf(returnDateInput);

        // Update the return date in the borrowed table
        returnStmt.setDate(1, returnDate);  // Set the return date
        returnStmt.setString(2, borrowerUsername);  // Set the borrower username
        returnStmt.setInt(3, bookId);  // Set the book ID

        int rowsAffected = returnStmt.executeUpdate();

        // If the return was successful, update the stock of the book
        if (rowsAffected > 0) {
            // Update the stock of the book by incrementing it
            updateStmt.setInt(1, bookId);  // Set the book ID to update the stock
            int stockUpdateResult = updateStmt.executeUpdate();

            if (stockUpdateResult > 0) {
                System.out.println("Book returned successfully! Stock updated.");
                return true;
            } else {
                System.out.println("Failed to update stock. Something went wrong.");
                return false;
            }
        } else {
            System.out.println("Failed to return the book. No borrowing record found.");
            return false;
        }
    } catch (SQLException e) {
        e.printStackTrace();
        return false;
    }
}


    
    public void registerNewAdmin(){
        Scanner sc = new Scanner(System.in);
         System.out.println("Enter admin username:");
                    String newAdminUsername = sc.nextLine();
                    System.out.println("Enter admin password:");
                    String newAdminPassword = sc.nextLine();
                    admin_Class newAdmin = new admin_Class(newAdminUsername, newAdminPassword);
                    if (newAdmin.signUpAdmin(newAdminUsername, newAdminPassword)) {
                        System.out.println("Admin signed up successfully!");
                    } else {
                        System.out.println("Admin sign-up failed. Try again.");
                    }
    }
    private boolean isUsernameTaken(String username) {
        String query = "SELECT COUNT(*) FROM admin WHERE usernameAdmin = ?";
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement stmt = connection.prepareStatement(query)) {

            stmt.setString(1, username);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return rs.getInt(1) > 0;  // If count > 0, username exists
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;  // Username doesn't exist
    }
     public boolean borrowBook() {
        String UPDATE_BOOK_STOCK = "UPDATE book SET stock = stock - 1 WHERE idBook = ? AND stock > 0";  // Decrease stock by 1
        Scanner scanner = new Scanner(System.in);

        // Admin enters borrower username
        System.out.print("Enter Borrower Username: ");
        String borrowerUsername = scanner.nextLine();

        // Check if borrower exists
        if (!doesUserExist(borrowerUsername)) {
            System.out.println("The borrower username does not exist.");
            return false; // Exit if the borrower does not exist
        }

        // Admin enters book ID
        System.out.print("Enter Book ID: ");
        int bookId = scanner.nextInt();

        // Check if book exists
        if (!doesBookExist(bookId)) {
            System.out.println("The book with the provided ID does not exist.");
            return false; // Exit if the book does not exist
        }

        // Admin enters borrow date
        System.out.print("Enter Borrow Date (YYYY-MM-DD): ");
        String borrowDateInput = scanner.next(); // User input for date


        // Insert the borrowing record into the 'borrowed' table
        try (Connection conn = getConnection();
           PreparedStatement borrowStmt = conn.prepareStatement(BORROW_BOOK);
         PreparedStatement updateStmt = conn.prepareStatement(UPDATE_BOOK_STOCK)) {

            borrowStmt.setString(1, borrowerUsername);  // Set borrower username
            borrowStmt.setInt(2, bookId);                // Set book ID
            borrowStmt.setString(3, borrowDateInput);
            int rowsAffected = borrowStmt.executeUpdate();
           if (rowsAffected > 0) {
            updateStmt.setInt(1, bookId);
            int stockUpdateResult = updateStmt.executeUpdate();
            
            if (stockUpdateResult > 0) {
                System.out.println("Book borrowed successfully! Stock updated.");
                return true;
            } else {
                System.out.println("Failed to update stock. Book might be out of stock.");
                return false;
            }
        } else {
            System.out.println("Failed to borrow the book.");
            return false;
        }
        } catch (SQLException e) {
            e.printStackTrace();
            return false; // Return false in case of SQL error
        }
    }
    private boolean doesBookExist(int bookId) {
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(CHECK_BOOK_EXISTS)) {

            stmt.setInt(1, bookId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return rs.getInt(1) > 0; // If count > 0, book exists
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;  // Book doesn't exist
    }
    private boolean doesUserExist(String username) {
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(CHECK_USER_EXISTS)) {

            stmt.setString(1, username);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return rs.getInt(1) > 0; // If count > 0, user exists
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;  // User doesn't exist
    }

}
