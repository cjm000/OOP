package oop_final_project;

import java.util.Scanner;
import java.io.*;
public class Oop_Final_Project {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int choice;

        // Display the initial menu
        do {
            
            System.out.println("Library System");
            System.out.println("[1] User Login");
            System.out.println("[2] Admin Login");
            System.out.println("[3] User Sign Up");
            System.out.println("[4] Exit");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();
            System.out.print("--------------------------------------------------\n");
            sc.nextLine(); // consume the newline character
        
            switch (choice) {
                case 1:
                    user_Class user = new user_Class(0, "", "", null, null, null);
                    user.tryUser();
                    break;

                case 2:
                    admin_Class admin = new admin_Class(null,"");
                    admin.tryAdmin();
                    break;

                case 3:                 
                    user_Class newUser = new user_Class(0, null, null, null, null, null);
                    newUser.registerUser();                  
                    break;

                case 4:
                    System.out.println("Exiting...");
                    break;

                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 4);

        sc.close();
    } 
}
